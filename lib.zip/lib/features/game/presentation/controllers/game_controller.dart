import 'package:flutter/material.dart';
import '../../domain/events/game_log_context.dart';
import '../../domain/models/player_model.dart';
import '../../domain/models/virus_model.dart';
import '../../domain/services/game_engine.dart';
import '../../domain/services/game_logger_adapter.dart';

class GameController extends ChangeNotifier {
  final GameEngine _engine;
  final GameLoggerAdapter _loggerAdapter;
  final String gameId;

  late List<List<VirusModel>> _grid;
  late List<PlayerModel> _players;
  int _currentPlayerIndex = 0;
  int _turnNumber = 1;
  bool _isGameOver = false;
  late final DateTime _matchStartTime;

  GameController({
    required GameEngine engine,
    required GameLoggerAdapter loggerAdapter,
    required int rows,
    required int cols,
    required List<PlayerModel> players,
    String? gameId,
  })  : _engine = engine,
        _loggerAdapter = loggerAdapter,
        _players = players,
        gameId = gameId ?? 'GAME-${DateTime.now().millisecondsSinceEpoch}' {
    _matchStartTime = DateTime.now();
    _grid = List.generate(
      rows,
      (_) => List.generate(cols, (_) => const VirusModel.empty()),
    );
  }

  // Getters for UI read access
  List<List<VirusModel>> get grid => _grid;
  List<PlayerModel> get players => _players;
  PlayerModel get currentPlayer => _players[_currentPlayerIndex];
  bool get isGameOver => _isGameOver;
  int get turnNumber => _turnNumber;

  /// Called when a cell on the grid is tapped
  void onCellTapped(int row, int col) {
    if (_isGameOver) return;

    final context = GameLogContext(
      gameId: gameId,
      moveId: 'MOVE-$_turnNumber',
      turnNumber: _turnNumber,
      playerId: currentPlayer.id,
      playerName: currentPlayer.name,
    );

    // Run move execution and chain simulation through the engine
    final result = _engine.executeTurn(
      grid: _grid,
      players: _players,
      currentPlayerIndex: _currentPlayerIndex,
      targetRow: row,
      targetCol: col,
      context: context,
      matchStartTime: _matchStartTime,
    );

    // Forward all emitted events to the logger
    _loggerAdapter.handleEvents(result.events);

    // Apply the engine's updated state
    _grid = result.updatedGrid;
    _players = result.updatedPlayers;
    _currentPlayerIndex = result.nextPlayerIndex;
    _isGameOver = result.isGameOver;
    _turnNumber++;

    // Notify listeners so GameScreen updates the view
    notifyListeners();
  }
}
