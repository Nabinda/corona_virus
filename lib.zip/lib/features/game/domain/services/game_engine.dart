import '../events/game_events.dart';
import '../events/game_log_context.dart';
import '../logic/board_evaluator.dart';
import '../logic/reaction_simulator.dart';
import '../models/player_model.dart';
import '../models/virus_model.dart';

class GameEngineResult {
  final List<List<VirusModel>> updatedGrid;
  final List<PlayerModel> updatedPlayers;
  final int nextPlayerIndex;
  final List<GameEvent> events;
  final bool isGameOver;

  const GameEngineResult({
    required this.updatedGrid,
    required this.updatedPlayers,
    required this.nextPlayerIndex,
    required this.events,
    required this.isGameOver,
  });
}

class GameEngine {
  final BoardEvaluator evaluator;
  final ReactionSimulator simulator;

  const GameEngine({
    required this.evaluator,
    required this.simulator,
  });

  /// Executes a full turn: validates the move, simulates reactions,
  /// measures reaction duration, evaluates player eliminations, and advances the turn.
  GameEngineResult executeTurn({
    required List<List<VirusModel>> grid,
    required List<PlayerModel> players,
    required int currentPlayerIndex,
    required int targetRow,
    required int targetCol,
    required GameLogContext context,
    required DateTime matchStartTime,
  }) {
    final activePlayer = players[currentPlayerIndex];
    final events = <GameEvent>[];

    events.add(MoveAttempted(context, row: targetRow, col: targetCol));

    // 1. Move Validation
    if (!evaluator.isValidMove(
      grid: grid,
      row: targetRow,
      col: targetCol,
      playerId: activePlayer.id,
    )) {
      events.add(MoveRejected(
        context,
        row: targetRow,
        col: targetCol,
        reason: 'Cell is not empty and belongs to an opponent',
      ));
      return GameEngineResult(
        updatedGrid: grid,
        updatedPlayers: players,
        nextPlayerIndex: currentPlayerIndex,
        events: events,
        isGameOver: false,
      );
    }

    events.add(MoveAccepted(context, row: targetRow, col: targetCol));

    // 2. Simulate chain reaction and track performance with Stopwatch
    final stopwatch = Stopwatch()..start();
    final simulation = simulator.simulate(
      initialGrid: grid,
      startRow: targetRow,
      startCol: targetCol,
      playerColor: activePlayer.color,
      context: context,
    );
    stopwatch.stop();

    events.addAll(simulation.events);

    // 3. Reaction performance event (only if a reaction occurred)
    if (simulation.totalExplosions > 0) {
      events.add(ReactionChainCompleted(
        context,
        duration: stopwatch.elapsed,
        maxChainDepth: simulation.maxChainDepth,
        totalExplosions: simulation.totalExplosions,
        totalSpreads: simulation.totalSpreads,
      ));
    }

    // 4. Update player states (mark first turn completed)
    var updatedPlayers = List<PlayerModel>.from(players);
    updatedPlayers[currentPlayerIndex] = activePlayer.markFirstTurnCompleted();

    // 5. Check for player eliminations
    // In Chain Reaction, a player is eliminated only after they've had at least one turn
    // and currently hold 0 viruses on the board.
    final livingPlayerCellCounts = <int, int>{};
    for (final player in updatedPlayers) {
      if (player.isAlive) livingPlayerCellCounts[player.id] = 0;
    }

    for (final row in simulation.updatedGrid) {
      for (final cell in row) {
        if (!cell.isEmpty &&
            livingPlayerCellCounts.containsKey(cell.playerId)) {
          livingPlayerCellCounts[cell.playerId!] =
              (livingPlayerCellCounts[cell.playerId!] ?? 0) + 1;
        }
      }
    }

    // Process newly defeated players
    for (int i = 0; i < updatedPlayers.length; i++) {
      final p = updatedPlayers[i];
      if (p.isAlive &&
          p.hasTakenFirstTurn &&
          (livingPlayerCellCounts[p.id] ?? 0) == 0) {
        updatedPlayers[i] = p.markEliminated();

        final remainingAlive =
            updatedPlayers.where((player) => player.isAlive).length;
        events.add(PlayerEliminated(
          context,
          eliminatedPlayerId: p.id,
          eliminatedPlayerName: p.name,
          remainingPlayers: remainingAlive,
        ));
      }
    }

    // 6. Check for victory condition
    final alivePlayers = updatedPlayers.where((p) => p.isAlive).toList();
    final allEligibleStarted = updatedPlayers.every((p) => p.hasTakenFirstTurn);

    if (allEligibleStarted && alivePlayers.length == 1) {
      final winner = alivePlayers.first;
      events.add(GameFinished(
        context,
        winnerPlayerId: winner.id,
        winnerPlayerName: winner.name,
        matchDuration: DateTime.now().difference(matchStartTime),
      ));

      return GameEngineResult(
        updatedGrid: simulation.updatedGrid,
        updatedPlayers: updatedPlayers,
        nextPlayerIndex: currentPlayerIndex,
        events: events,
        isGameOver: true,
      );
    }

    // 7. Advance turn to the next living player
    int nextIndex = (currentPlayerIndex + 1) % updatedPlayers.length;
    while (!updatedPlayers[nextIndex].isAlive) {
      nextIndex = (nextIndex + 1) % updatedPlayers.length;
    }

    events.add(TurnEnded(
      context,
      duration: stopwatch.elapsed,
    ));

    return GameEngineResult(
      updatedGrid: simulation.updatedGrid,
      updatedPlayers: updatedPlayers,
      nextPlayerIndex: nextIndex,
      events: events,
      isGameOver: false,
    );
  }
}
