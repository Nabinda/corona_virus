import 'package:flutter/material.dart';

class PlayerModel {
  final int id;
  final String name;
  final Color color;

  /// Tracks whether the player has placed their very first virus.
  /// Crucial so players with 0 cells aren't eliminated before taking their first turn.
  final bool hasTakenFirstTurn;

  /// False when the player has no remaining viruses after their first turn.
  final bool isAlive;

  const PlayerModel({
    required this.id,
    required this.name,
    required this.color,
    this.hasTakenFirstTurn = false,
    this.isAlive = true,
  });

  /// Convenience factory for new games.
  factory PlayerModel.create({
    required int id,
    required String name,
    required Color color,
  }) {
    return PlayerModel(
      id: id,
      name: name,
      color: color,
      hasTakenFirstTurn: false,
      isAlive: true,
    );
  }

  /// Marks that the player has entered the match by playing their first turn.
  PlayerModel markFirstTurnCompleted() {
    return copyWith(hasTakenFirstTurn: true);
  }

  /// Eliminates the player from the game.
  PlayerModel markEliminated() {
    return copyWith(isAlive: false);
  }

  PlayerModel copyWith({
    int? id,
    String? name,
    Color? color,
    bool? hasTakenFirstTurn,
    bool? isAlive,
  }) {
    return PlayerModel(
      id: id ?? this.id,
      name: name ?? this.name,
      color: color ?? this.color,
      hasTakenFirstTurn: hasTakenFirstTurn ?? this.hasTakenFirstTurn,
      isAlive: isAlive ?? this.isAlive,
    );
  }

  @override
  String toString() => 'PlayerModel(id: $id, name: $name, alive: $isAlive)';

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is PlayerModel &&
          runtimeType == other.runtimeType &&
          id == other.id &&
          name == other.name &&
          color == other.color &&
          hasTakenFirstTurn == other.hasTakenFirstTurn &&
          isAlive == other.isAlive;

  @override
  int get hashCode =>
      id.hashCode ^
      name.hashCode ^
      color.hashCode ^
      hasTakenFirstTurn.hashCode ^
      isAlive.hashCode;
}
