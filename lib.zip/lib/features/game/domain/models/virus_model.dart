// lib/features/game/domain/models/virus_model.dart
import 'package:flutter/material.dart';

class VirusModel {
  final int virusCount;
  final int? playerId;
  final Color? color;

  const VirusModel._({
    required this.virusCount,
    this.playerId,
    this.color,
  }) : assert(
          (virusCount == 0 && playerId == null && color == null) ||
              (virusCount > 0 && playerId != null && color != null),
          'A cell with viruses must have a playerId and color. An empty cell must not.',
        );

  /// Creates a completely unoccupied cell.
  const VirusModel.empty() : this._(virusCount: 0);

  /// Creates an occupied cell belonging to a specific player.
  const VirusModel.occupied({
    required int virusCount,
    required int playerId,
    required Color color,
  }) : this._(
          virusCount: virusCount,
          playerId: playerId,
          color: color,
        );

  bool get isEmpty => virusCount == 0;

  bool canBePlayedBy(int activePlayerId) {
    return isEmpty || playerId == activePlayerId;
  }

  /// Increments count and assigns/retains ownership.
  VirusModel addVirus({required int playerId, required Color color}) {
    return VirusModel.occupied(
      virusCount: virusCount + 1,
      playerId: playerId,
      color: color,
    );
  }

  /// Decrements count after an explosion.
  /// Automatically transitions to empty if the count reaches 0.
  VirusModel explode(int threshold) {
    final remaining = virusCount - threshold;
    if (remaining <= 0) {
      return const VirusModel.empty();
    }
    return VirusModel.occupied(
      virusCount: remaining,
      playerId: playerId!,
      color: color!,
    );
  }

  @override
  String toString() => isEmpty
      ? 'VirusModel(empty)'
      : 'VirusModel(count: $virusCount, player: $playerId)';
}
