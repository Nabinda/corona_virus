/// Immutable metadata that correlates events to a specific game, turn, and player action.
class GameLogContext {
  /// Unique identifier for the match (e.g. "GAME-1712039481").
  final String gameId;

  /// Unique identifier for the move within the match (e.g. "MOVE-14").
  final String moveId;

  /// Current turn count in the game.
  final int turnNumber;

  /// ID of the player initiating or owning this event.
  final int playerId;

  /// Display name of the active player.
  final String playerName;

  const GameLogContext({
    required this.gameId,
    required this.moveId,
    required this.turnNumber,
    required this.playerId,
    required this.playerName,
  });

  /// Allows creating a derived context (e.g., when the turn increments).
  GameLogContext copyWith({
    String? gameId,
    String? moveId,
    int? turnNumber,
    int? playerId,
    String? playerName,
  }) {
    return GameLogContext(
      gameId: gameId ?? this.gameId,
      moveId: moveId ?? this.moveId,
      turnNumber: turnNumber ?? this.turnNumber,
      playerId: playerId ?? this.playerId,
      playerName: playerName ?? this.playerName,
    );
  }

  Map<String, dynamic> toMap() => {
        'gameId': gameId,
        'moveId': moveId,
        'turn': turnNumber,
        'playerId': playerId,
        'player': playerName,
      };
}
