import '../models/virus_model.dart';

/// Topographical position of a cell on the grid.
enum CellTopology { corner, edge, center }

class BoardEvaluator {
  final int rows;
  final int cols;

  const BoardEvaluator({required this.rows, required this.cols});

  /// Identifies whether a cell is a corner, edge, or interior center tile.
  CellTopology getTopology(int row, int col) {
    final isRowEdge = row == 0 || row == rows - 1;
    final isColEdge = col == 0 || col == cols - 1;

    if (isRowEdge && isColEdge) return CellTopology.corner;
    if (isRowEdge || isColEdge) return CellTopology.edge;
    return CellTopology.center;
  }

  /// Critical mass (threshold) before a cell bursts:
  /// - Corner cells: 2 (capacity 1, explodes at 2)
  /// - Edge cells:   3 (capacity 2, explodes at 3)
  /// - Center cells: 4 (capacity 3, explodes at 4)
  int getCriticalMass(int row, int col) {
    return switch (getTopology(row, col)) {
      CellTopology.corner => 2,
      CellTopology.edge => 3,
      CellTopology.center => 4,
    };
  }

  /// True if adding one virus will trigger an explosion.
  bool isAboutToExplode(int row, int col, VirusModel cell) {
    return (cell.virusCount + 1) >= getCriticalMass(row, col);
  }

  /// Returns valid orthogonal neighbor coordinates (Up, Down, Left, Right).
  List<({int row, int col})> getNeighbors(int row, int col) {
    final neighbors = <({int row, int col})>[];
    if (row > 0) neighbors.add((row: row - 1, col: col)); // Up
    if (row < rows - 1) neighbors.add((row: row + 1, col: col)); // Down
    if (col > 0) neighbors.add((row: row, col: col - 1)); // Left
    if (col < cols - 1) neighbors.add((row: row, col: col + 1)); // Right
    return neighbors;
  }

  /// Validates whether a move can legally be played by the active player.
  bool isValidMove({
    required List<List<VirusModel>> grid,
    required int row,
    required int col,
    required int playerId,
  }) {
    // 1. Boundary check
    if (row < 0 || row >= rows || col < 0 || col >= cols) return false;

    // 2. Ownership check (can play if empty or belongs to active player)
    return grid[row][col].canBePlayedBy(playerId);
  }
}
