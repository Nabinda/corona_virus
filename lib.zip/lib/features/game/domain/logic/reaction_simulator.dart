import 'package:flutter/material.dart';
import '../events/game_events.dart';
import '../events/game_log_context.dart';
import '../models/virus_model.dart';
import 'board_evaluator.dart';

class SimulationResult {
  final List<List<VirusModel>> updatedGrid;
  final List<GameEvent> events;
  final int maxChainDepth;
  final int totalExplosions;
  final int totalSpreads;

  const SimulationResult({
    required this.updatedGrid,
    required this.events,
    required this.maxChainDepth,
    required this.totalExplosions,
    required this.totalSpreads,
  });
}

class ReactionSimulator {
  final BoardEvaluator evaluator;

  const ReactionSimulator(this.evaluator);

  /// Executes a single move and resolves all subsequent explosions iteratively.
  SimulationResult simulate({
    required List<List<VirusModel>> initialGrid,
    required int startRow,
    required int startCol,
    required Color playerColor,
    required GameLogContext context,
  }) {
    final events = <GameEvent>[];

    // Deep clone the grid so we never mutate the original in-place
    final grid = initialGrid.map((row) => List<VirusModel>.from(row)).toList();

    // 1. Apply the user's initial move
    final originCell = grid[startRow][startCol];
    grid[startRow][startCol] = originCell.addVirus(
      playerId: context.playerId,
      color: playerColor,
    );

    events.add(CellUpdated(
      context,
      row: startRow,
      col: startCol,
      virusCount: grid[startRow][startCol].virusCount,
    ));

    final initialThreshold = evaluator.getCriticalMass(startRow, startCol);

    // If the cell hasn't reached critical mass, no chain reaction happens
    if (grid[startRow][startCol].virusCount < initialThreshold) {
      return SimulationResult(
        updatedGrid: grid,
        events: events,
        maxChainDepth: 0,
        totalExplosions: 0,
        totalSpreads: 0,
      );
    }

    // Critical mass reached: Start reaction sequence
    events.add(ReactionStarted(
      context,
      originRow: startRow,
      originCol: startCol,
    ));

    // Breadth-First Search queue: Tracks (row, col, current chain depth)
    final queue = <({int row, int col, int depth})>[];
    queue.add((row: startRow, col: startCol, depth: 0));

    int totalExplosions = 0;
    int totalSpreads = 0;
    int maxChainDepth = 0;

    while (queue.isNotEmpty) {
      final current = queue.removeAt(0);
      final r = current.row;
      final c = current.col;
      final depth = current.depth;

      if (depth > maxChainDepth) {
        maxChainDepth = depth;
      }

      final cell = grid[r][c];
      final threshold = evaluator.getCriticalMass(r, c);

      // Check if this cell still needs to explode
      if (cell.virusCount >= threshold) {
        totalExplosions++;
        events.add(VirusExploded(
          context,
          row: r,
          col: c,
          chainDepth: depth,
        ));

        // Explode the cell (subtracts threshold, clears owner if count hits 0)
        grid[r][c] = cell.explode(threshold);

        // Distribute to orthogonal neighbors
        final neighbors = evaluator.getNeighbors(r, c);
        for (final neighbor in neighbors) {
          totalSpreads++;
          final nr = neighbor.row;
          final nc = neighbor.col;

          events.add(VirusSpread(
            context,
            fromRow: r,
            fromCol: c,
            toRow: nr,
            toCol: nc,
            chainDepth: depth,
          ));

          // Neighbor receives a virus and converts ownership
          final targetCell = grid[nr][nc];
          grid[nr][nc] = targetCell.addVirus(
            playerId: context.playerId,
            color: playerColor,
          );

          // If the neighbor now exceeds its threshold, enqueue it for the next depth
          if (grid[nr][nc].virusCount >= evaluator.getCriticalMass(nr, nc)) {
            queue.add((row: nr, col: nc, depth: depth + 1));
          }
        }
      }
    }

    return SimulationResult(
      updatedGrid: grid,
      events: events,
      maxChainDepth: maxChainDepth,
      totalExplosions: totalExplosions,
      totalSpreads: totalSpreads,
    );
  }
}
